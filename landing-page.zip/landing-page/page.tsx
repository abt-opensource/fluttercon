import Example from './example'
import HeroSection from './hero'

const page = () => {
  return (
    <div>
      <HeroSection/>
      <Example/>
    </div>
  )
}

export default page